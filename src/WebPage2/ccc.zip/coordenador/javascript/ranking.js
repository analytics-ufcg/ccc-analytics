var duration = 1000;
var aluno = "";
var val_per,line_per;

//funcao para plotar a barra de acordo com o que foi selecionado
function getRanking(){
    console.log("BUG - RANKING - TRACK 03 - getRanking[id_aluno = " + id_aluno +"]");
    aluno = id_aluno;
    $("#infos").empty();
    plot_bar_disciplina_ranking(id_aluno);
}

function plot_bar_disciplina_ranking(nome){
    console.log("BUG - RANKING - TRACK 04 - plot_bar_disciplina_ranking[id_aluno = " + id_aluno +"]");
    var h1 = 60;
    var margin = {top: 30, right: 120, bottom: 40, left: 60},
            width = 950 - margin.left - margin.right,
            height = 600 - margin.top - margin.bottom;
    d3.select("#infos").select("svg").remove();
    var svg = d3.select("#infos");
    
    svg = d3.select("#infos").append("svg")
        .attr("width", 800)
        .attr("height", 115);

    var periodo_aluno = nome.substring(1,4);
    
    console.log("BUG - RANKING - TRACK 05 - plot_bar_disciplina_ranking[periodo_aluno = " + periodo_aluno +"]");

    val_per = dados_ranking.filter(function(d){ 

		console.log("d.media = "+d.media);
		return d.periodo == periodo_aluno



		});
    line_per =  [{'x' : d3.min(val_per,function(d){return parseFloat(d.media);}) , 'y' : h1},
                         {'x':(d3.max(val_per,function(d){return parseFloat(d.media);})), 'y' : h1}];

    console.log("BUG - RANKING - TRACK 06 - plot_bar_disciplina_ranking[val_per.length = " + val_per.length +"]");
    console.log("-------------")
    if (val_per.length<2) {
        // Imprime mensagem
        svg.append("text")
            .attr("y", h1-30)
            .attr("x", 550)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            .attr("font-weight", "bold");
            //.text("Este é o único aluno do período 20" + periodo_aluno.substring(0,2) + "\." + periodo_aluno.substring(2,3));
    }else{
        plot_ranges_ranking(svg, line_per, h1);
        plot_bars_ranking(svg, line_per, h1);
        
        // Imprime a matricula escolhido
        svg.append("text")
            .attr("y", h1-50)
            .attr("x", 20)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            .attr("font-weight", "bold")
            .text("Aluno: ");
        svg.append("text")
            .attr("y", h1-50)
            .attr("x", 75)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            //.attr("font-weight", "bold")
            .text(nome);

        // Imprime o periodo do aluno escolhido
        svg.append("text")
            .attr("y", h1-38)
            .attr("x", 20)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            .attr("font-weight", "bold")
            .text("Período:");
        svg.append("text")
            .attr("y", h1-38)
            .attr("x", 75)
            .attr("text-anchor", "center")
            .attr("font-size", "12px");
            //.attr("font-weight", "bold")
            //.text("20" + periodo_aluno.substring(0,2) + "\." + periodo_aluno.substring(2,3));
            
        // Imprime a quantidade de alunos do periodo escolhido
        svg.append("text")
            .attr("y", h1-26)
            .attr("x", 20)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            .attr("font-weight", "bold")
            .text("Turma:");
        svg.append("text")
            .attr("y", h1-26)
            .attr("x", 75)
            .attr("text-anchor", "center")
            .attr("font-size", "12px")
            //.attr("font-weight", "bold")
            .text(val_per.length + " alunos");
            
	console.log ("val_per.length---------------------"+val_per.media);
        plot_alunos_ranking(svg, val_per, "blue",line_per[0], line_per[1],h1);
    };
}


function plot_ranges_ranking(svg, dados, y0){
    console.log("dados.length = " + dados.length);
    var valor1 = String(dados[0].x).replace(/\,/g,'');
    var valor2 = String(dados[1].x).replace(/\,/g,'');
    
    var x1 = d3.scale.linear()
          .domain([parseFloat(valor1), parseFloat(valor2)])
          .range([120, 750]);    

    var xAxis = d3.svg.axis()
            .scale(x1)
            .orient("bottom")
            .tickValues([parseFloat(valor1),parseFloat(valor2)])
            .ticks(6);
    
        
        // Adiciona o texto "Min"
        svg.append("text")
            .attr("x", x1(dados[0].x) - 30) // X de onde o texto vai aparecer
            .attr("y", (y0 -2))           // Y de onde o texto vai aparecer
            .text("Min");
        //adiciona a nota minima
        svg.append("text")
            .attr("x",x1(dados[0].x) - 30)
            .attr("y",(y0 + 8))
            .text(valor1);

        // Adiciona o texto "Max"
        svg.append("text")
            .attr("x", x1(dados[1].x) + 10) // X de onde o texto vai aparecer
            .attr("y", (y0 -2))            // Y de onde o texto vai aparecer   
            .text("Max");    
        //adiciona a nota minima
        svg.append("text")
            .attr("x",x1(dados[1].x) + 10)
            .attr("y",(y0 + 8))
            .text(valor2);
}

/* Funcao para plotar uma barrinha*/
function addLine_ranking(svg,x1,x2,y1,y2,cor){
    
    if(y1 > 100){
        svg.append("line")
              .attr("x1", x1)
              .attr("x2", x2)
              .attr("y1",y1)
              .attr("y2",y2)
              .attr("id","barra_indicador_altura_" + y1)
              .transition().duration(duration)
              .style("stroke",cor)
              .attr("stroke-width",25);
    }else{
        svg.append("line")
              .attr("x1", x1)
              .attr("x2", x2)
              .attr("y1",y1)
              .attr("y2",y2)
              .attr("id","barra_indicador_altura_" + y1)
              .transition().duration(duration)
              .style("stroke",cor)
              .attr("opacity",0.6)
              .attr("stroke-width",25);
    }
}

/* Plota a barrinha de fundo horizontal das notas*/
function plot_bars_ranking(svg, dados,y0){
    
    var x1 = d3.scale.linear()
          .domain([dados[0].x, dados[1].x])
          .range([120, 750]);
    
    addLine_ranking(svg,x1(dados[0].x),x1(dados[1].x),y0,y0,"#C7C7C7");
}


function convert(nota,min,max){
    return (((nota- min)/(max-min))*(750-120)) + 120;
}

function plot_alunos_ranking(svg, dados, cor, minx, maxx, y0){
    var inf = dados.filter(function(d) {return d.matricula == aluno});
    
    
    function mousemove(nota, matricula) { 
        svg.append("text")
        .attr("x", function(d){ return convert(nota,minx.x,maxx.x) ;})
        .attr("y",(y0 +34)) // Altura de onde o texto vai aparecer
        .attr("text-anchor", "middle")
        .style("fill","black")
        .text(matricula + ": " + nota);

	//mostrarBarrasParalelas2(matricula);
    } 

    // Funcao que faz o tolltip sumir 
    function mouseout(nota, matricula) {
      svg.append("text")
        .attr("x", function(d){ return convert(nota,minx.x,maxx.x) ;})
        .attr("y",(y0 +34)) // Altura de onde o texto vai aparecer
        .attr("text-anchor", "middle")
        .attr("font-weight", "bold")
        .style("fill","white")
        .style("stroke","white")
        .style("stroke-width",2)
        .text(matricula + ": " + nota);
    } 

    // Adiciona o texto do ranking
    svg.append("text")
        .attr("x", function(d){ return convert(inf[0].media,minx.x,maxx.x) - 15;})
        .attr("y",(y0 - 15)) // Altura de onde o texto vai aparecer
        .attr("text-anchor", "middle")
        .attr("font-size", "12px")
        .text(inf[0].posicao + "º colocado");
    
    // Adiciona o texto da nota do aluno selecionado 
    svg.append("text")
        .attr("x", function(d){ return convert(inf[0].media,minx.x,maxx.x) ;})
        .attr("y",(y0 + 25)) // Altura de onde o texto vai aparecer
        .attr("text-anchor", "middle")
        .attr("font-weight", "bold")
        .text(inf[0].media);

    var g = svg.append("g");

    // Adiciona as linhas correspondente as notas de cada aluno
    g.selectAll("line").data(dados)
                    .enter()
                    .append("line")
                    .attr("x1", function(d){ return convert(d.media,minx.x,maxx.x);}) // Angulacao superior da linha 
                    .attr("x2", function(d){ return convert(d.media,minx.x,maxx.x);}) // Angulacao inferior da linha
                    .attr("y1",y0-12) // Altura superior da linha
                    .attr("y2",y0+12) // Altura inferior da linha
                    .attr("class","linha_aluno")
                    .transition().duration(duration) // Transicao
                    .style("stroke","#377EB8") // Cor da linha
                    .attr("stroke-width",5)    // Largura da linha
                    .attr("text",function(d){return d.matricula;});

    g.selectAll("line").on("mouseout", function(d){mouseout(d.media, d.matricula);}) 
                       .on("mousemove", function(d){mousemove(d.media, d.matricula);})
                       .on("click", function(d) {mostrarBarrasParalelas2(d.matricula);/*console.log(d.matricula + "  " + d.media);*/});


    // Adiciona a linha correspondente a media do aluno escolhido

    svg.append("line")
	    .data(val_per)
            .attr("x1", function(d){ return convert(inf[0].media,minx.x,maxx.x);}) // X inicial da linha
            .attr("x2", function(d){ return convert(inf[0].media,minx.x,maxx.x);}) // X final da linha 
            .attr("y1",y0-12) // Y inicial da linha
            .attr("y2",y0+12) // Y final da linha
            .attr("class","linha_aluno")
            .transition().duration(duration)  // Transicao
            .style("stroke","#E41A1C") // Cor da linha
            .attr("stroke-width",5)    // Largura da linha
            .attr("text",function(d){
			console.log("tamanho de d "+d);
			return d.matricula;

		});
    
   


}
